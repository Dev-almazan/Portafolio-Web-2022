import logo from '../../img/media/rn1.jpg';
import './Cargando.css';


const Cargando = ()=>
{

    return(
        <div id='cargando'>
            <img className='rotate' src={logo}></img>
        </div>

    )
}

export default Cargando;